"""
Statistical Distribution Functions
"""

from __future__ import (division, generators, absolute_import,
                        print_function, with_statement, nested_scopes,
                        unicode_literals)
import numpy as np

from scipy.special import xlogy

from tsdst.tmath import norm


def negloglike_logreg(parms, X, Y, lamb=1, l_norm=1):

    intercept = parms[0]
    betas = parms[1:]
    
    mu = X.dot(parms)
    Ypred = 1.0/(1.0 + np.exp(-mu))
    #Ypred = np.sum([Ypred >= 0.5], axis=0)
    loglike = np.sum(xlogy(Y, Ypred) + xlogy(1.0 - Y, 1.0 - Ypred)) - lamb*norm(betas, l_norm)

    return -loglike


def posterior_logreg_lasso(parms, X, Y, l_scale=0.5):
    n_mu = 0
    n_sigma = 10
    l_loc = 0
    # a common choice for the laplace prior is scale = 2/lambda, where lambda is the L1 penalty,
    # or scale = 2*C. I find that when scale == C, you get similar results. This
    # parameterization is similar to scale = stddev/lambda or scale = stddev*C, where I set stddev to 1
    
    intercept = parms[0]
    betas = parms[1:]
    
    mu = X.dot(parms)
    Ypred = 1.0/(1.0 + np.exp(-mu))
    like = np.sum(Y*np.log(Ypred) + (1.0 - Y)*np.log(1.0 - Ypred))
    # normal prior on the intercept
    int_prior = (-0.5*np.log(2.0*np.pi) - np.log(n_sigma) - (((intercept - n_mu)**2) / (2.0*(n_sigma**2))))
    # Laplace prior 
    parm_prior = np.sum(-np.log(2*l_scale) - (np.abs(betas - l_loc)/l_scale))
    post = like + parm_prior + int_prior 
    return post


def adaptive_posterior_logreg_lasso(parms, X, Y, l_scale=None):
    n_mu = 0
    n_sigma = 1
    l_loc = 0
    # assuming an exponential prior for the scale parameter of the laplace
    # mean/scale of 0.38 seemed to work well for these experiments
    l_scale_rate = 1/0.38
    
    intercept = parms[0]
    betas = parms[1:-1]
    l_scale = np.exp(parms[-1])
    
    mu = X.dot(parms[:-1].reshape(-1, )).reshape(-1, )
    Ypred = 1/(1 + np.exp(-mu))
    like = np.sum(Y*np.log(Ypred) + (1 - Y)*np.log(1 - Ypred))
    # normal prior on the intercept
    int_prior = (-0.5*np.log(2.0*np.pi) - np.log(n_sigma) - (((intercept - n_mu)**2) / (2*(n_sigma**2))))
    # Laplace prior for Coefficient
    parm_prior = np.sum(-np.log(2*l_scale) - (np.abs(betas - l_loc)/l_scale))
    # exponential prior for scale parameter
    scale_prior = np.log(l_scale_rate) - l_scale_rate * l_scale
    # post = likelihood + laplace prior + jacobian for laplace scale + laplace scale prior
    post = like + int_prior + parm_prior + parms[-1] + scale_prior
    return post