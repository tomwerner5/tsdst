from __future__ import (division, generators, absolute_import,
                        print_function, with_statement, nested_scopes,
                        unicode_literals)
import datetime
import numpy as np
import os
import pandas as pd
import pickle
import sys

from getpass import getpass
from sqlalchemy import create_engine
from timeit import default_timer as dt


def pde_getTable(user, sql, pw=None, convert_unicode=False, pool_recyle=10,
                 pool_size=20, echo=False):
                 #max_identifier_length=128):
    dsn = """
        (DESCRIPTION =
            (ADDRESS =
                (PROTOCOL = TCP)
            (HOST = 10.10.61.61)
            (PORT = 1521)
        )
        (CONNECT_DATA =
            (SERVICE_NAME = pdea)
        ))
    """
    
    if pw is None or pw == '':
        pw = getpass(prompt='Password: ')
    
    conn = 'oracle://{user}:{password}@{dsn}'.format(
        user=user,
        password=pw,
        dsn=dsn
    )

    engine = create_engine(conn, convert_unicode=convert_unicode,
                           pool_recycle=pool_recyle,
                           pool_size=pool_size, echo=echo)
                           #max_identifier_length=max_identifier_length)
    data = None
    if isinstance(sql, str):
        data = pd.read_sql(sql, engine)
    else:
        data = []
        for query in sql:
            data.append(pd.read_sql(query, engine))
    engine.dispose()
    
    return data


def pretty_print_time(ts, te=None):
    if te is None:
        t = ts
    else:
        t = te - ts
    h = np.floor(t/3600.0)
    m = np.floor(((t/3600.0) - h) * 60.0)
    s = ((((t/3600.0) - h) * 60.0) - m) * 60.0
    
    if len(str(int(h))) == 1:
        h = "0" + str(int(h))
    else:
        h = str(int(h))
    
    if len(str(int(m))) == 1:
        m = "0" + str(int(m))
    else:
        m = str(int(m))
    
    if len(str(int(np.round(s)))) == 1:
        s = "0" + str(int(np.round(s, 3)))
    else:
        s = str(int(np.round(s, 3)))
    
    pretty = h + ":" + m + ":" + s
    return pretty


def checkDir(dirc):
    if not os.path.isdir(dirc):
        os.mkdir(dirc)


def print_message_with_time(msg, ts, te=None, display_realtime=True, backsn=False,
                            log=False, log_dir="log", log_filename="", log_args="a"):
    printed = msg + pretty_print_time(ts, te)
    date_time = datetime.datetime.now().strftime("%-I:%M:%S %p (%b %d)")
    if display_realtime:
        printed = printed + " Current Time: " + date_time
    if backsn:
        printed = printed + "\n"
    sys.stdout.write(printed)
    sys.stdout.flush()
    checkDir(log_dir)
    logfile = log_dir + "/" + log_filename + ".log"
    logfile = logfile.replace("//", "/")
    if log:
        with open(log_dir + "/" + log_filename + ".log", log_args) as f:
            f.write(printed)
    return printed
    

def print_time(*args, **kwargs):
    print_message_with_time(*args, **kwargs)


def save_checkpoint(obj, msg, ts=None, te=None, display_realtime=True, backsn=False,
                    log=True, log_dir="log", log_filename="", log_args="a",
                    checkpoint_dir="checkpoints", checkpoint_filename="",
                    checkpoint_extension="pkl", checkpoint_args="wb"):
    print_message_with_time(msg=msg, ts=ts, te=te, display_realtime=display_realtime,
                            backsn=backsn, log=log, log_dir=log_dir, log_filename=log_filename,
                            log_args=log_args)
    checkDir(checkpoint_dir)
    file = checkpoint_dir + '/' + checkpoint_filename + "." + checkpoint_extension
    file = file.replace('//', '/')
    if checkpoint_extension == 'pkl':
        with open(file, checkpoint_args) as f:
            pickle.dump(obj, f, protocol=pickle.HIGHEST_PROTOCOL)


def updateProgBar(curIter, totalIter, t0, barLength=20):
    status = "Working..."
    progress = float(curIter)/float(totalIter)
    if isinstance(progress, int):
        progress = float(progress)
    if progress >= 1:
        progress = 1
        status = "Finished!..."
    block = int(round(barLength*progress))
    text = "\rPercent: [{0}] {1:.2f}% iter: {2}/{3} {4} Elapsed: {5}, Estimated: {6}".format(
        "#"*block + "-"*(barLength - block), 
        round(progress*100.0, 2), curIter, totalIter, status, pretty_print_time(t0, dt()),
        pretty_print_time((dt()-t0)/curIter * (totalIter - curIter)))
    if progress >= 1:
        sys.stdout.write(text + "\r\n")
        sys.stdout.flush()
    else:
        sys.stdout.write(text)
        sys.stdout.flush()
        
        
def move_columns_to_end(data, col):
    if not isinstance(col, list):
        col = list(col)
    data = data[[c for c in data if c not in col] + col]
    return data


def keywordSearch(keywords, data):
    keyword_cols = []
    for i in data.columns:
        present = False
        for keyword in keywords:
            if keyword == "FIN" and "FINAL" in i:
                continue
            else:
                if keyword in i:
                    present = True
        if present:
            keyword_cols.append(i)
    return keyword_cols


def splitCol(data, search_col, search_list, split_pat):
    exists = []
    noneCount = 0
    for i in data.index:
        if data.loc[i, search_col] is None:
            noneCount += 1
        else:
            found_splits = data.loc[i, search_col].split(split_pat)
            exists.append([1 if val in found_splits else 0 for val in search_list])
    return exists, noneCount


def toFrame(todf, fromdf):
    return pd.DataFrame(todf, index=fromdf.index, columns=fromdf.columns)
